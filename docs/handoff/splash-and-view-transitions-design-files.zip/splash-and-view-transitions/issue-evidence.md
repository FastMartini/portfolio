# Reported map glitch — evidence and review questions

The user reports: “There is a problem with the map. The map paint is churning and making the map glitch. There are blocks that are green.” The requested deliverable is a handoff covering the opening splash, Climb → List, and List → Climb. No fix was requested as part of this packaging task.

## Evidence status

- Green blocks and visible glitch: user-reported symptom.
- Paint churn as the cause: user’s description/hypothesis; not measured or independently confirmed in this packaging session.
- Exact failing sequence, browser/version, OS/device, DPR, theme, viewport, zoom level, cold/warm cache behavior and GPU conditions: not yet supplied. An optional question was sent while packaging; this capture does not assume an answer.
- No fresh browser reproduction, trace, screenshot, screen recording, screenshot-baseline check or test run was performed. The PNGs in this package are actual authored/generated map assets, not images of the defect.

## Source-backed facts to inspect

All three sequences use `mapOverlayMarkup`, generated face markup, the same print PNGs and motion CSS. The initial overlay is owned by React; transition overlays are fresh namespaced DOM copies inserted into `body`. Each printed face contains an SVG image and live SVG lettering via `use`; panes crop the same full map with different viewBoxes. Wide/tall variants are chosen at aspect ratio 4/5.

Paper is #f3eedd; the table backdrop has a dark green radial gradient. Faces have opaque paper backing, overflow clipping, flattened transform trees, visible browser backfaces, authored complementary opacity steps, and an animated top-pane stacking order. The controller also animates camera scale, map rotateX, rig/table translation, screen-space paper and masks. Blurred shadows are present on the opening and List → Climb; Climb → List hides them. These are inspection targets, not proof of a renderer bug.

The rasterizer’s source comment describes using lossless PNG to avoid WebP chroma bleeding into paper. This is historical rationale in the current source, not a diagnosis of the reported green blocks. Generated markup also carries an older `raster.py` comment, but the current npm pipeline invokes the supplied Chromium `.mjs` rasterizer. Follow executable imports/scripts rather than that stale comment.

## Candidate explanations to distinguish, not conclusions

1. Lost/re-rasterized tiles or oversized compositing surfaces while scaling/clipping the map; green backdrop might be exposed if opaque paper paint disappears.
2. Incorrect face opacity/stacking or a one-frame transition between CSS and Web Animations clocks, exposing the backdrop despite valid texture data.
3. Image availability/decode, SVG image/use invalidation, responsive asset switching, or mismatched generated assets.
4. Invalidations from the underlying scene, theme updates, fonts or layout observers while the transition overlay is active.

Do not equate a green pixel with lost paint without distinguishing intended artwork/backdrop from unexpected rectangular regions. Do not presume a GPU-memory problem, prescribe `will-change`, or reuse an older mountain-scrolling diagnosis without a matched reproduction.

## Evidence Claude should request or plan

Capture uninterrupted playback in a visible browser for each sequence, with environment details and the exact timestamps of green blocks. Compare that playback against paused review frames: `seek` intentionally freezes clocks and can hide transient failures. Compare warm and cold image loads and repeated toggles. Keep normal conditions separate from any constrained GPU experiment. Collect paint/raster/compositor traces where the browser supports them, and correlate visible artifacts with trace events and face states. Check backdrop exposure with a diagnostic backing color only as a temporary experiment; changing the backdrop must not count as fixing the defect.

Test one rendering or lifecycle variable at a time and retain before/after evidence. Compare viable repair directions and cost: preserve live lettering with better paint bounds/lifecycle; flatten/cache only suitable static faces; or simplify map layering. Any change in art fidelity, responsive framing, reduced-motion behavior, or architecture needs an explicit tradeoff.
