# Splash animation and Climb/List transition handoff

Captured 2026-11-18 02:34:56 EST (-0500), `feat/about-continuous-trail` at `723612c`.

1. Open `splash-and-view-transitions-design-handoff.md` and use its opening prompt with Claude.
2. Read `issue-evidence.md` for the user-reported green blocks, evidence limits, hypotheses and reproduction questions.
3. Browse `source/components/splash/` for runtime code, `source/scripts/` for generators, `source/public/splash/` for actual print assets, and `source/tests/` for existing checks.

There are 87 complete project source/asset files plus these documents and `manifest.json`. Source paths are preserved. The Markdown embeds core implementation and selected integration excerpts; ZIP source files are complete. The index in the Markdown lists included and omitted material. This is a focused review bundle, not a runnable repository export. Use the full repo for reproduction and implementation.

No implementation changes, artwork regeneration, browser reproduction or application tests were performed to prepare this archive. Green blocks are a user-reported symptom; paint churn/root cause is not independently confirmed. PNG files here are actual map artwork, not captured failure evidence. No source was sent to an external service.

## Replay and test plan for the full repository

Use the existing `npm run dev` command. In a fresh eligible homepage session with no fragment and full motion, observe the opening. To replay, clear only the `splash-seen` session-storage entry and reload. Use the actual “Climb view” and “List view” buttons for both transitions; repeat from different reading/scene positions. Record the real browser/environment and uninterrupted playback. Do not equate paused `seek` frames with continuous playback.

Existing targeted tests (commands for the full repo, not run during packaging):

```sh
npm test -- tests/splash.spec.ts tests/feather-splash.spec.ts tests/map-polish.spec.ts tests/climb-transition.spec.ts tests/list-transition.spec.ts --project=chromium --workers=1
```

The Playwright config builds its own static export under `/portfolio/`; it does not silently reuse the development server. WebKit and other compatibility checks should follow the actual config and available browsers. Read `AGENTS.md` and installed Next.js guides before code changes.

## Integrity

`manifest.json` records current Git metadata, file sizes and SHA-256 hashes. ZIP integrity, member hashes, source freshness and the Markdown source blocks were checked. The original repository files remain unchanged by this task.
