import { PortfolioHeader } from "../components/portfolio-shell";
import { ListNavigation } from "../components/list-navigation";
import { JourneyTrail } from "../components/about/JourneyTrail";
import { ListView } from "../components/list-view";
import { journeySections } from "../content/journey";
import { Climb } from "../components/climb/Climb";
import { ViewToggle } from "../components/climb/ViewToggle";
import { MountainArt } from "../components/climb/Mountain";
import { StopCards } from "../components/climb/StopCards";
import { WaypointContent } from "../components/waypoint-content";
import { caseStudySlots } from "../components/climb/CaseStudies";
import { waypoints } from "../content/waypoints";
import { homeMetadata } from "../content/site";

import "./ascent.css";
import "../components/about/about.css";

export const metadata = homeMetadata;

const homeNavigation = [
  { href: "#about", label: "About" },
  { href: "#work", label: "Work" },
  { kind: "resume", label: "Resume" },
  { href: "#summit", label: "Contact" },
] as const;

export default function Home() {
  return (
    <Climb mountain={<MountainArt />} cards={<StopCards />}
      header={<PortfolioHeader
        homeHref="#trailhead"
        homeAriaLabel="Diego Martinez, home"
        links={homeNavigation}
        navLabel="Primary navigation"
        action={<ViewToggle />}
      />}
      summaries={Object.fromEntries(waypoints.map((waypoint) => [waypoint.slug,
        <WaypointContent key={waypoint.slug} waypoint={waypoint} titleId={`panel-${waypoint.slug}-title`} />]))}
      cases={caseStudySlots("panel-case-")}>
      <ListNavigation sections={journeySections}>
        <main id="main-content">
          <ListView />
          <JourneyTrail />
        </main>
      </ListNavigation>

      <footer>
        <p>© {new Date().getFullYear()} Diego Martinez</p>
        <a href="#trailhead">Back to the trailhead ↑</a>
      </footer>
    </Climb>
  );
}
