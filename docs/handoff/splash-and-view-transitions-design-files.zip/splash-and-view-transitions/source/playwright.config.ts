import { defineConfig, devices } from "@playwright/test";

const testSite = {
  host: "127.0.0.1",
  port: Number.parseInt(process.env.TEST_SITE_PORT ?? "4173", 10),
  basePath: process.env.TEST_SITE_BASE_PATH ?? "/portfolio",
} as const;

const testOrigin = `http://${testSite.host}:${testSite.port}`;
const testBaseUrl = `${testOrigin}${testSite.basePath}/`;

export default defineConfig({
  testDir: "./tests",
  snapshotPathTemplate: "{testDir}/{testFilePath}-snapshots/{arg}-{projectName}-{platform}{ext}",
  expect: {
    toHaveScreenshot: { maxDiffPixelRatio: 0.01 },
  },
  fullyParallel: true,
  forbidOnly: Boolean(process.env.CI),
  retries: process.env.CI ? 2 : 0,
  reporter: process.env.CI ? "github" : "list",
  use: {
    baseURL: testBaseUrl,
    trace: "retain-on-failure",
    screenshot: "only-on-failure",
  },
  projects: [
    {
      name: "chromium",
      use: { ...devices["Desktop Chrome"] },
    },
    {
      name: "firefox-adaptive",
      testMatch: ["about-redesign.spec.ts", "about-interaction.spec.ts", "theme.spec.ts", "climb-adaptive.spec.ts", "climb-audio.spec.ts", "climb-trees.spec.ts", "climb-rendering.spec.ts", "climb-mountain.spec.ts", "splash.spec.ts", "feather-splash.spec.ts", "map-polish.spec.ts", "climb-transition.spec.ts", "list-transition.spec.ts", "discoverability.spec.ts", "trailhead-hero.spec.ts", "hero-branding.spec.ts"],
      use: { ...devices["Desktop Firefox"] },
    },
    {
      name: "webkit-adaptive",
      testMatch: ["about-redesign.spec.ts", "about-interaction.spec.ts", "theme.spec.ts", "climb-adaptive.spec.ts", "climb-audio.spec.ts", "climb-trees.spec.ts", "climb-rendering.spec.ts", "climb-mountain.spec.ts", "splash.spec.ts", "feather-splash.spec.ts", "map-polish.spec.ts", "climb-transition.spec.ts", "list-transition.spec.ts", "discoverability.spec.ts", "trailhead-hero.spec.ts", "hero-branding.spec.ts"],
      use: { ...devices["Desktop Safari"] },
    },
  ],
  webServer: {
    command: "npm run build:test && node scripts/serve-static-export.mjs",
    url: testBaseUrl,
    env: {
      NEXT_PUBLIC_BASE_PATH: testSite.basePath,
      NEXT_PUBLIC_SITE_URL: process.env.TEST_PUBLIC_SITE_URL ?? `${testOrigin}${testSite.basePath}`,
      TEST_SITE_BASE_PATH: testSite.basePath,
      TEST_SITE_HOST: testSite.host,
      TEST_SITE_PORT: String(testSite.port),
    },
    // Never silently test a stale export or another worktree's server.
    reuseExistingServer: false,
    timeout: 120_000,
  },
});
